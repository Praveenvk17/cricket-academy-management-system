-- =====================================================
-- 1. Drop Existing Database
-- WARNING: This deletes the complete database and data
-- =====================================================

DROP DATABASE IF EXISTS cricket_academy_db;


-- =====================================================
-- 2. Create Database
-- =====================================================

CREATE DATABASE cricket_academy_db;

USE cricket_academy_db;


-- =====================================================
-- 3. Users Table
-- Stores ADMIN, COACH and PLAYER users
-- =====================================================

CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,

    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL,
    password VARCHAR(255) NOT NULL,

    role ENUM('ADMIN', 'COACH', 'PLAYER')
        NOT NULL DEFAULT 'PLAYER',

    specialization ENUM(
        'BATTING',
        'FAST_BOWLING',
        'SPIN_BOWLING',
        'WICKET_KEEPING',
        'ALL_ROUNDER',
        'GENERAL'
    ) DEFAULT 'GENERAL',

    experience INT DEFAULT 0,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- =====================================================
-- 4. Batches Table
-- Each batch can have maximum 15 members
-- Coach ID references users table
-- =====================================================

CREATE TABLE batches (
    id INT PRIMARY KEY AUTO_INCREMENT,

    batch_name VARCHAR(100) NOT NULL,

    coach_id INT NOT NULL,

    timing VARCHAR(50) NOT NULL,

    skill_level ENUM(
        'BEGINNER',
        'INTERMEDIATE',
        'ADVANCED'
    ) NOT NULL,

    monthly_fee DECIMAL(8,2) NOT NULL,

    max_members INT NOT NULL DEFAULT 15,

    FOREIGN KEY (coach_id)
        REFERENCES users(id)
        ON DELETE CASCADE
);


-- =====================================================
-- 5. Enrollments Table
-- Stores player-to-batch assignments
-- =====================================================

CREATE TABLE enrollments (
    id INT PRIMARY KEY AUTO_INCREMENT,

    player_id INT NOT NULL,

    batch_id INT NOT NULL,

    enrollment_date DATE NOT NULL,

    status ENUM('ACTIVE', 'INACTIVE')
        DEFAULT 'ACTIVE',

    FOREIGN KEY (player_id)
        REFERENCES users(id)
        ON DELETE CASCADE,

    FOREIGN KEY (batch_id)
        REFERENCES batches(id)
        ON DELETE CASCADE,

    UNIQUE KEY unique_player_batch (player_id, batch_id)
);


-- =====================================================
-- 6. Performance Records Table
-- Stores player performance evaluations
-- =====================================================

CREATE TABLE performance_records (
    id INT PRIMARY KEY AUTO_INCREMENT,

    player_id INT NOT NULL,

    coach_id INT NOT NULL,

    session_date DATE NOT NULL,

    runs_scored INT DEFAULT 0,

    balls_faced INT DEFAULT 0,

    wickets_taken INT DEFAULT 0,

    overs_bowled DECIMAL(4,1) DEFAULT 0.0,

    runs_conceded INT DEFAULT 0,

    fitness_rating INT CHECK (
        fitness_rating BETWEEN 1 AND 10
    ),

    coach_feedback VARCHAR(300),

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (player_id)
        REFERENCES users(id)
        ON DELETE CASCADE,

    FOREIGN KEY (coach_id)
        REFERENCES users(id)
        ON DELETE CASCADE
);


-- =====================================================
-- 7. Uploaded Files Table
-- Stores player uploaded documents
-- =====================================================

CREATE TABLE uploaded_files (
    file_id INT PRIMARY KEY AUTO_INCREMENT,

    user_id INT NOT NULL,

    original_file_name VARCHAR(255) NOT NULL,

    saved_file_name VARCHAR(255) NOT NULL,

    file_path VARCHAR(500) NOT NULL,

    file_type VARCHAR(100),

    uploaded_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (user_id)
        REFERENCES users(id)
        ON DELETE CASCADE
);


-- =====================================================
-- 8. Insert Default Super Admin
-- =====================================================

INSERT INTO users
(
    full_name,
    email,
    phone,
    password,
    role,
    specialization,
    experience
)
VALUES
(
    'CEO OF RCB',
    'Rcb@academy.com',
    '8807355789',
    'rcb2526',
    'ADMIN',
    'general',
    0
);


-- =====================================================
-- 9. Insert Default Coach - Bhuvi
-- =====================================================

INSERT INTO users
(
    full_name,
    email,
    phone,
    password,
    role,
    specialization,
    experience
)
VALUES
(
    'Bhuvi Coach',
    'bhuvi@academy.com',
    '9678634780',
    'coach123',
    'COACH',
    'FAST_BOWLING',
    10
);


-- =====================================================
-- 10. Insert Default Player - Rohit
-- =====================================================

INSERT INTO users
(
    full_name,
    email,
    phone,
    password,
    role,
    specialization,
    experience
)
VALUES
(
    'Rohit Sharma Player',
    'rohit@academy.com',
    '9922367540',
    'player123',
    'PLAYER',
    'BATTING',
    0
);





-- =====================================================
-- 11. View All Users
-- =====================================================

SELECT
    id,
    full_name,
    email,
    phone,
    role,
    specialization,
    experience
FROM users
ORDER BY id;


-- =====================================================
-- 12. View Only Coaches
-- =====================================================

SELECT
    id,
    full_name,
    email,
    phone,
    role,
    specialization,
    experience
FROM users
WHERE role = 'COACH'
ORDER BY id DESC;


-- =====================================================
-- 13. View Only Players
-- =====================================================

SELECT
    id,
    full_name,
    email,
    phone,
    role,
    specialization,
    experience
FROM users
WHERE role = 'PLAYER'
ORDER BY id;


-- =====================================================
-- 14. View Batches
-- =====================================================

SELECT
    b.id,
    b.batch_name,
    b.coach_id,
    u.full_name AS coach_name,
    b.timing,
    b.skill_level,
    b.monthly_fee,
    b.max_members
FROM batches b
JOIN users u
    ON b.coach_id = u.id
ORDER BY b.id DESC;


-- =====================================================
-- 15. View Enrollments
-- =====================================================

SELECT
    e.id AS enrollment_id,
    e.player_id,
    p.full_name AS player_name,
    e.batch_id,
    b.batch_name,
    b.coach_id,
    c.full_name AS coach_name,
    e.enrollment_date,
    e.status
FROM enrollments e
JOIN users p
    ON e.player_id = p.id
JOIN batches b
    ON e.batch_id = b.id
JOIN users c
    ON b.coach_id = c.id
ORDER BY e.id DESC;


-- =====================================================
-- 16. View Performance Records
-- =====================================================

SELECT
    *
FROM performance_records
ORDER BY id DESC;


-- =====================================================
-- 17. View Uploaded Files
-- =====================================================

SELECT
    *
FROM uploaded_files
ORDER BY file_id DESC;


-- =====================================================
-- 18. View Coaches Again
-- =====================================================

SELECT
    id,
    full_name,
    email,
    phone,
    role,
    specialization,
    experience
FROM users
WHERE role = 'COACH'
ORDER BY id DESC;