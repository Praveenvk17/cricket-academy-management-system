package com.academy.dao;

import com.academy.model.Batch;
import com.academy.util.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BatchDAO {
    public boolean addBatch(Batch b) throws SQLException {
        String sql = "INSERT INTO batches(batch_name, coach_id, timing, skill_level, monthly_fee) VALUES(?, ?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, b.getBatchName());
            ps.setInt(2, b.getCoachId());
            ps.setString(3, b.getTiming());
            ps.setString(4, b.getSkillLevel());
            ps.setDouble(5, b.getMonthlyFee());
            return ps.executeUpdate() > 0;
        }
    }

    public List<Batch> findAll() throws SQLException {
        List<Batch> list = new ArrayList<>();
        String sql = "SELECT b.*, u.full_name AS coach_name FROM batches b JOIN users u ON b.coach_id = u.id ORDER BY b.id DESC";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Batch b = new Batch();
                b.setId(rs.getInt("id"));
                b.setBatchName(rs.getString("batch_name"));
                b.setCoachId(rs.getInt("coach_id"));
                b.setCoachName(rs.getString("coach_name"));
                b.setTiming(rs.getString("timing"));
                b.setSkillLevel(rs.getString("skill_level"));
                b.setMonthlyFee(rs.getDouble("monthly_fee"));
                list.add(b);
            }
        }
        return list;
    }
}