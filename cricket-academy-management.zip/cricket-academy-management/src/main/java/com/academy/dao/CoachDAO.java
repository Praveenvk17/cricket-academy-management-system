package com.academy.dao;

import com.academy.model.Coach;
import com.academy.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class CoachDAO {

    public boolean addCoach(Coach coach) {

        String sql = "INSERT INTO coaches "
                   + "(coach_name, specialization, experience, phone, email) "
                   + "VALUES (?, ?, ?, ?, ?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, coach.getCoachName());
            ps.setString(2, coach.getSpecialization());
            ps.setInt(3, coach.getExperience());
            ps.setString(4, coach.getPhone());
            ps.setString(5, coach.getEmail());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Coach> getAllCoaches() {

        List<Coach> coaches = new ArrayList<>();

        String sql = "SELECT * FROM coaches ORDER BY coach_id DESC";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Coach coach = new Coach();

                coach.setCoachId(rs.getInt("coach_id"));
                coach.setCoachName(rs.getString("coach_name"));
                coach.setSpecialization(rs.getString("specialization"));
                coach.setExperience(rs.getInt("experience"));
                coach.setPhone(rs.getString("phone"));
                coach.setEmail(rs.getString("email"));

                coaches.add(coach);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return coaches;
    }

    public boolean deleteCoach(int coachId) {

        String sql = "DELETE FROM coaches WHERE coach_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, coachId);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}