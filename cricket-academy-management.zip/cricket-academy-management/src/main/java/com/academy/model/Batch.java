package com.academy.model;

public class Batch {
    private int id, coachId;
    private String batchName, coachName, timing, skillLevel;
    private double monthlyFee;

    public int getId() { 
    	return id; 
    }
    public void setId(int id) {
    	this.id = id; 
    }
    public int getCoachId() {
    	return coachId;
    }
    public void setCoachId(int coachId) { 
    	this.coachId = coachId;
    }
    public String getBatchName() { 
    	return batchName;
    }
    public void setBatchName(String batchName) {
    	this.batchName = batchName;
    }
    public String getCoachName() { 
    	return coachName;
    }
    public void setCoachName(String coachName) {
    	this.coachName = coachName;
    }
    public String getTiming() { 
    	return timing;
    }
    public void setTiming(String timing) { 
    	this.timing = timing;
    }
    public String getSkillLevel() { 
    	return skillLevel;
    }
    public void setSkillLevel(String skillLevel) { 
    	this.skillLevel = skillLevel;
    }
    public double getMonthlyFee() { 
    	return monthlyFee;
    }
    public void setMonthlyFee(double monthlyFee) { 
    	this.monthlyFee = monthlyFee;
    }
}