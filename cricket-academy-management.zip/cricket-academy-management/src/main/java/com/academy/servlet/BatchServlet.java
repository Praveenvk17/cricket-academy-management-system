package com.academy.servlet;

import com.academy.dao.BatchDAO;
import com.academy.model.Batch;
import com.academy.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/add-batch")
public class BatchServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User user = (User) req.getSession().getAttribute("user");
        if (user == null || !"ADMIN".equals(user.getRole())) {
            resp.sendRedirect("login.jsp");
            return;
        }

        Batch b = new Batch();
        b.setBatchName(req.getParameter("batchName"));
        b.setCoachId(Integer.parseInt(req.getParameter("coachId")));
        b.setTiming(req.getParameter("timing"));
        b.setSkillLevel(req.getParameter("skillLevel"));
        b.setMonthlyFee(Double.parseDouble(req.getParameter("monthlyFee")));

        try {
            new BatchDAO().addBatch(b);
            resp.sendRedirect("admin-dashboard.jsp?success=Batch created successfully");
        } catch (Exception e) {
            resp.sendRedirect("admin-dashboard.jsp?error=Could not add batch");
        }
    }
}