<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<%@ page import="com.academy.model.User" %>
<%@ page import="com.academy.model.Coach" %>
<%@ page import="com.academy.dao.CoachDAO" %>
<%@ page import="java.util.List" %>

<%
    User admin = (User) session.getAttribute("user");

    if (admin == null || !"ADMIN".equalsIgnoreCase(admin.getRole())) {
        response.sendRedirect("login.jsp");
        return;
    }

    CoachDAO coachDAO = new CoachDAO();
    List<Coach> coaches = coachDAO.getAllCoaches();
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Coach Management</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">

    <style>
        body {
            background: #f4f7f6;
        }

        .navbar {
            background: #198754;
        }

        .page-title {
            color: #198754;
            font-weight: bold;
        }

        .card {
            border-radius: 15px;
        }

        .table th {
            background: #198754;
            color: white;
        }
    </style>
</head>

<body>

<nav class="navbar navbar-dark">
    <div class="container">
        <a class="navbar-brand fw-bold" href="admin-dashboard.jsp">
            Cricket Academy Management
        </a>

        <a href="admin-dashboard.jsp" class="btn btn-light btn-sm">
            Back to Dashboard
        </a>
    </div>
</nav>

<div class="container mt-4 mb-5">

    <h2 class="page-title mb-4">Coach Details Management</h2>

    <!-- Add Coach Form -->
    <div class="card shadow-sm border-0 p-4 mb-4">

        <h5 class="fw-bold mb-3">Add Coach Details</h5>

        <form action="addCoach" method="post">

            <div class="row g-3">

                <div class="col-md-6">
                    <label class="form-label">Coach Name</label>
                    <input type="text"
                           name="coachName"
                           class="form-control"
                           required>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Specialization</label>
                    <input type="text"
                           name="specialization"
                           class="form-control"
                           placeholder="Batting / Bowling / Fitness"
                           required>
                </div>

                <div class="col-md-4">
                    <label class="form-label">Experience (Years)</label>
                    <input type="number"
                           name="experience"
                           class="form-control"
                           min="0"
                           required>
                </div>

                <div class="col-md-4">
                    <label class="form-label">Phone</label>
                    <input type="text"
                           name="phone"
                           class="form-control"
                           required>
                </div>

                <div class="col-md-4">
                    <label class="form-label">Email</label>
                    <input type="email"
                           name="email"
                           class="form-control"
                           required>
                </div>

            </div>

            <button type="submit" class="btn btn-success mt-3">
                Add Coach
            </button>

        </form>
    </div>

    <!-- Coach List -->
    <div class="card shadow-sm border-0 p-4">

        <h5 class="fw-bold mb-3">Coach List</h5>

        <% if (coaches == null || coaches.isEmpty()) { %>

            <div class="alert alert-info">
                No coach details available.
            </div>

        <% } else { %>

            <div class="table-responsive">
                <table class="table table-bordered table-hover align-middle">

                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Coach Name</th>
                            <th>Specialization</th>
                            <th>Experience</th>
                            <th>Phone</th>
                            <th>Email</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        <% for (Coach coach : coaches) { %>

                        <tr>
                            <td><%= coach.getCoachId() %></td>
                            <td><%= coach.getCoachName() %></td>
                            <td><%= coach.getSpecialization() %></td>
                            <td><%= coach.getExperience() %> years</td>
                            <td><%= coach.getPhone() %></td>
                            <td><%= coach.getEmail() %></td>
                            <td>
                                <a href="<%= request.getContextPath() %>/deleteCoach?coachId=<%= coach.getCoachId() %>"
                                   class="btn btn-danger btn-sm"
                                   onclick="return confirm('Delete this coach?');">
                                    Delete
                                </a>
                            </td>
                        </tr>

                        <% } %>
                    </tbody>

                </table>
            </div>

        <% } %>

    </div>

</div>

</body>
</html>