<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<%@ page import="com.academy.model.User" %>
<%@ page import="com.academy.dao.UserDAO" %>
<%@ page import="com.academy.dao.BatchDAO" %>
<%@ page import="com.academy.model.Batch" %>
<%@ page import="com.academy.util.ReportService" %>

<%@ page import="java.util.List" %>
<%@ page import="java.util.Map" %>

<%
    User user = (User) session.getAttribute("user");

    if (user == null || !"ADMIN".equalsIgnoreCase(user.getRole())) {
        response.sendRedirect("login.jsp");
        return;
    }

    // =========================
    // Delete User
    // =========================
    String deleteIdParam = request.getParameter("deleteId");

    if (deleteIdParam != null && !deleteIdParam.trim().isEmpty()) {
        try {
            int deleteId = Integer.parseInt(deleteIdParam.trim());

            new UserDAO().deleteUser(deleteId);

            response.sendRedirect(
                request.getContextPath()
                + "/admin-dashboard.jsp?success=Member+deleted+successfully"
            );
            return;

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // =========================
    // Search, Filter and Pagination
    // =========================
    String search = request.getParameter("search");
    String roleFilter = request.getParameter("role");

    int currentPage = 1;
    int pageSize = 5;

    String pageParam = request.getParameter("page");

    if (pageParam != null && !pageParam.trim().isEmpty()) {
        try {
            currentPage = Integer.parseInt(pageParam);

            if (currentPage < 1) {
                currentPage = 1;
            }

        } catch (NumberFormatException e) {
            currentPage = 1;
        }
    }

    UserDAO userDAO = new UserDAO();

    List<User> userList = userDAO.getUsersWithFilter(
        search,
        roleFilter,
        currentPage,
        pageSize
    );

    int totalUsers = userDAO.getTotalUserCount(search, roleFilter);

    int totalPages = (int) Math.ceil((double) totalUsers / pageSize);

    List<Batch> batches = new BatchDAO().findAll();

    // =========================
    // Analytics
    // =========================
    List<User> allUsers = userDAO.findByRole("PLAYER");
    allUsers.addAll(userDAO.findByRole("COACH"));

    ReportService reportService = new ReportService();

    Map<String, Long> roleStats =
        reportService.getUserRoleCounts(allUsers);
%>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Admin Dashboard - Cricket Academy</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
        rel="stylesheet">

    <style>
        body {
            background-color: #f8f9fa;
        }

        .card {
            border-radius: 12px;
        }

        .navbar-brand {
            letter-spacing: 0.3px;
        }

        .table th {
            white-space: nowrap;
        }

        .dashboard-card {
            transition: transform 0.2s ease;
        }

        .dashboard-card:hover {
            transform: translateY(-3px);
        }

        .small-card-text {
            min-height: 48px;
        }
    </style>
</head>

<body>

    <!-- =========================
         Top Navigation
    ========================== -->
    <nav class="navbar navbar-dark bg-primary px-4 shadow">

        <span class="navbar-brand fw-bold">
            🏏 Cricket Academy Admin Hub
        </span>

        <div>
            <a
                href="<%= request.getContextPath() %>/coach-dashboard.jsp"
                class="btn btn-outline-light btn-sm me-2">
                Go to Coach View
            </a>

            <a
                href="<%= request.getContextPath() %>/logout"
                class="btn btn-outline-light btn-sm">
                Logout
            </a>
        </div>

    </nav>


    <div class="container-fluid my-4 px-4">

        <!-- =========================
             Success Message
        ========================== -->
        <% if (request.getParameter("success") != null) { %>

            <div class="alert alert-success alert-dismissible fade show">
                <%= request.getParameter("success") %>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="alert">
                </button>
            </div>

        <% } %>


        <!-- =========================
             Upload Status
        ========================== -->
        <% if ("success".equals(request.getParameter("upload"))) { %>

            <div class="alert alert-info alert-dismissible fade show">
                Document uploaded successfully!

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="alert">
                </button>
            </div>

        <% } else if ("failed".equals(request.getParameter("upload"))) { %>

            <div class="alert alert-danger alert-dismissible fade show">
                File upload failed. Please try again with a valid file.

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="alert">
                </button>
            </div>

        <% } %>


        <!-- =========================
             Analytics Cards
        ========================== -->
        <div class="row g-3 mb-4">

            <!-- Total Players -->
            <div class="col-md-4">
                <div class="card bg-white p-3 border-0 shadow-sm border-start border-primary border-4">

                    <span class="text-muted small fw-bold">
                        TOTAL REGISTERED PLAYERS
                    </span>

                    <h3 class="fw-bold mb-0 text-primary">
                        <%= roleStats.getOrDefault("PLAYER", 0L) %>
                    </h3>

                </div>
            </div>


            <!-- Active Coaches -->
            <div class="col-md-4">
                <div class="card bg-white p-3 border-0 shadow-sm border-start border-warning border-4">

                    <span class="text-muted small fw-bold">
                        ACTIVE COACHES
                    </span>

                    <h3 class="fw-bold mb-0 text-warning">
                        <%= roleStats.getOrDefault("COACH", 0L) %>
                    </h3>

                </div>
            </div>


            <!-- Total Batches -->
            <div class="col-md-4">
                <div class="card bg-white p-3 border-0 shadow-sm border-start border-success border-4">

                    <span class="text-muted small fw-bold">
                        TOTAL ACTIVE BATCHES
                    </span>

                    <h3 class="fw-bold mb-0 text-success">
                        <%= batches.size() %>
                    </h3>

                </div>
            </div>

        </div>


        <!-- =========================
             Main Dashboard Row
        ========================== -->
        <div class="row g-4">

            <!-- =========================
                 Left Column
            ========================== -->
            <div class="col-lg-4 col-md-5">

                <!-- Schedule New Batch -->
                <div class="card p-4 shadow-sm border-0 mb-4">

                    <h5 class="fw-bold text-primary mb-3">
                        Schedule New Batch
                    </h5>

                    <form
                        action="<%= request.getContextPath() %>/add-batch"
                        method="post">

                        <div class="mb-2">
                            <label class="form-label small">
                                Batch Name
                            </label>

                            <input
                                type="text"
                                name="batchName"
                                class="form-control"
                                placeholder="U-19 Morning Pace"
                                required>
                        </div>


                        <div class="mb-2">
                            <label class="form-label small">
                                Coach ID
                            </label>

                            <input
                                type="number"
                                name="coachId"
                                class="form-control"
                                value="2"
                                required>
                        </div>


                        <div class="mb-2">
                            <label class="form-label small">
                                Timing
                            </label>

                            <input
                                type="text"
                                name="timing"
                                class="form-control"
                                placeholder="06:30 AM - 08:30 AM"
                                required>
                        </div>


                        <div class="mb-2">
                            <label class="form-label small">
                                Skill Level
                            </label>

                            <select
                                name="skillLevel"
                                class="form-select">

                                <option value="BEGINNER">
                                    Beginner
                                </option>

                                <option value="INTERMEDIATE">
                                    Intermediate
                                </option>

                                <option value="ADVANCED">
                                    Advanced
                                </option>

                            </select>
                        </div>


                        <div class="mb-3">
                            <label class="form-label small">
                                Monthly Fee (₹)
                            </label>

                            <input
                                type="number"
                                name="monthlyFee"
                                class="form-control"
                                value="2500"
                                required>
                        </div>


                        <button
                            type="submit"
                            class="btn btn-primary w-100">
                            Create Batch
                        </button>

                    </form>

                </div>


                <!-- Player Uploaded Documents -->
                <div class="card p-4 shadow-sm border-0 mb-4 dashboard-card">

                    <h5 class="fw-bold mb-3">
                        Player Uploaded Documents
                    </h5>

                    <p class="text-muted">
                        View and download documents uploaded by players.
                    </p>

                    <a
                        href="<%= request.getContextPath() %>/admin-documents.jsp"
                        class="btn btn-dark">
                        View Player Documents
                    </a>

                </div>


                <!-- =========================
                     Service Reports + Coach Management
                     Same Row
                ========================== -->
                <div class="row g-3 mb-4">

                    <!-- Service Reports -->
                    <div class="col-6">

                        <div class="card p-3 shadow-sm border-0 h-100 dashboard-card">

                            <h5 class="text-primary fw-bold">
                                Service Reports
                            </h5>

                            <p class="text-muted small-card-text">
                                View player performance and training evaluation reports.
                            </p>

                            <a
                                href="<%= request.getContextPath() %>/service-report.jsp"
                                class="btn btn-primary w-100 mt-auto">
                                View Reports
                            </a>

                        </div>

                    </div>


                    <!-- Coach Details Management -->
                    <div class="col-6">

                        <div class="card p-3 shadow-sm border-0 h-100 dashboard-card">

                            <h5 class="text-success fw-bold">
                                Coach Management
                            </h5>

                            <p class="text-muted small-card-text">
                                Add, view and manage academy coach details.
                            </p>

                            <a
                                href="<%= request.getContextPath() %>/coach-management.jsp"
                                class="btn btn-success w-100 mt-auto">
                                Manage Coaches
                            </a>

                        </div>

                    </div>

                </div>

            </div>


            <!-- =========================
                 Right Column
            ========================== -->
            <div class="col-lg-8 col-md-7">

                <!-- Registered Members -->
                <div class="card p-4 shadow-sm border-0 mb-4">

                    <h5 class="fw-bold mb-3">
                        Academy Members Directory
                    </h5>


                    <!-- Search and Filter -->
                    <form
                        action="<%= request.getContextPath() %>/admin-dashboard.jsp"
                        method="get"
                        class="row g-2 mb-3">

                        <div class="col-md-6">

                            <input
                                type="text"
                                name="search"
                                class="form-control form-control-sm"
                                placeholder="Search by name, email, or phone..."
                                value="<%= search != null ? search : "" %>">

                        </div>


                        <div class="col-md-4">

                            <select
                                name="role"
                                class="form-select form-select-sm">

                                <option value="ALL">
                                    All Roles
                                </option>

                                <option
                                    value="PLAYER"
                                    <%= "PLAYER".equals(roleFilter) ? "selected" : "" %>>
                                    Players
                                </option>

                                <option
                                    value="COACH"
                                    <%= "COACH".equals(roleFilter) ? "selected" : "" %>>
                                    Coaches
                                </option>

                            </select>

                        </div>


                        <div class="col-md-2">

                            <button
                                type="submit"
                                class="btn btn-secondary btn-sm w-100">
                                Filter
                            </button>

                        </div>

                    </form>


                    <!-- Users Table -->
                    <div class="table-responsive">

                        <table class="table table-hover align-middle">

                            <thead class="table-light">

                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Role</th>
                                    <th>Specialization</th>
                                    <th class="text-center">Action</th>
                                </tr>

                            </thead>


                            <tbody>

                                <% if (userList.isEmpty()) { %>

                                    <tr>
                                        <td
                                            colspan="6"
                                            class="text-center text-muted py-3">
                                            No members found matching your search.
                                        </td>
                                    </tr>

                                <% } else {

                                    for (User u : userList) {

                                %>

                                    <tr>

                                        <td>
                                            <strong>
                                                <%= u.getFullName() %>
                                            </strong>
                                        </td>

                                        <td>
                                            <%= u.getEmail() %>
                                        </td>

                                        <td>
                                            <%= u.getPhone() %>
                                        </td>

                                        <td>

                                            <span
                                                class="badge
                                                <%= "COACH".equals(u.getRole())
                                                    ? "bg-warning text-dark"
                                                    : ("ADMIN".equals(u.getRole())
                                                        ? "bg-primary"
                                                        : "bg-info text-dark") %>">

                                                <%= u.getRole() %>

                                            </span>

                                        </td>

                                        <td>
                                            <%= u.getSpecialization() %>
                                        </td>

                                        <td class="text-center">

                                            <% if (!"ADMIN".equals(u.getRole())) { %>

                                                <a
                                                    href="<%= request.getContextPath() %>/admin-dashboard.jsp?deleteId=<%= u.getId() %>"
                                                    class="btn btn-outline-danger btn-sm py-0 px-2"
                                                    onclick="return confirm('Are you sure you want to delete <%= u.getFullName() %>?');">
                                                    Delete
                                                </a>

                                            <% } else { %>

                                                <span class="badge bg-secondary">
                                                    System
                                                </span>

                                            <% } %>

                                        </td>

                                    </tr>

                                <%
                                    }
                                }
                                %>

                            </tbody>

                        </table>

                    </div>


                    <!-- Pagination -->
                    <% if (totalPages > 1) { %>

                        <nav class="d-flex justify-content-between align-items-center mt-2">

                            <span class="small text-muted">
                                Showing Page
                                <%= currentPage %>
                                of
                                <%= totalPages %>
                                (<%= totalUsers %> records)
                            </span>


                            <ul class="pagination pagination-sm mb-0">

                                <% for (int i = 1; i <= totalPages; i++) { %>

                                    <li
                                        class="page-item <%= (i == currentPage) ? "active" : "" %>">

                                        <a
                                            class="page-link"
                                            href="<%= request.getContextPath() %>/admin-dashboard.jsp?page=<%= i %>&search=<%= search != null ? search : "" %>&role=<%= roleFilter != null ? roleFilter : "ALL" %>">

                                            <%= i %>

                                        </a>

                                    </li>

                                <% } %>

                            </ul>

                        </nav>

                    <% } %>

                </div>


                <!-- Active Academy Batches -->
                <div class="card p-4 shadow-sm border-0">

                    <h5 class="fw-bold mb-3">
                        Active Academy Batches
                    </h5>


                    <div class="table-responsive">

                        <table class="table table-hover align-middle">

                            <thead class="table-light">

                                <tr>
                                    <th>Batch Name</th>
                                    <th>Coach</th>
                                    <th>Timing</th>
                                    <th>Level</th>
                                    <th>Fee</th>
                                </tr>

                            </thead>


                            <tbody>

                                <% if (batches.isEmpty()) { %>

                                    <tr>
                                        <td
                                            colspan="5"
                                            class="text-center text-muted py-3">
                                            No batches created yet.
                                        </td>
                                    </tr>

                                <% } else {

                                    for (Batch b : batches) {

                                %>

                                    <tr>

                                        <td>
                                            <strong>
                                                <%= b.getBatchName() %>
                                            </strong>
                                        </td>

                                        <td>
                                            <%= b.getCoachName() %>
                                        </td>

                                        <td>
                                            <%= b.getTiming() %>
                                        </td>

                                        <td>

                                            <span class="badge bg-secondary">
                                                <%= b.getSkillLevel() %>
                                            </span>

                                        </td>

                                        <td>
                                            ₹<%= b.getMonthlyFee() %>
                                        </td>

                                    </tr>

                                <%
                                    }
                                }
                                %>

                            </tbody>

                        </table>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <script
        src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js">
    </script>

</body>

</html>