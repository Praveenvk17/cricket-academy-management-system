<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<%@ page import="com.academy.model.User" %>
<%@ page import="com.academy.dao.PerformanceDAO" %>
<%@ page import="com.academy.model.Performance" %>
<%@ page import="com.academy.dao.UploadedFileDAO" %>
<%@ page import="com.academy.model.UploadedFile" %>
<%@ page import="java.util.List" %>

<%
    User user = (User) session.getAttribute("user");

    // Check player login
    if (user == null || !"PLAYER".equalsIgnoreCase(user.getRole())) {
        response.sendRedirect("login.jsp");
        return;
    }

    // Get player's performance records
    List<Performance> list =
            new PerformanceDAO().findByPlayer(user.getId());

    // Get player's uploaded files
    List<UploadedFile> uploadedFiles =
            new UploadedFileDAO().getFilesByUser(user.getId());

    // Upload status message
    String uploadStatus = request.getParameter("upload");
    String uploadMessage = request.getParameter("message");
%>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Player Dashboard</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
        rel="stylesheet">

    <style>
        body {
            background-color: #f4f7fb;
        }

        .card {
            border-radius: 12px;
        }

        .table th {
            white-space: nowrap;
        }

        .table td {
            vertical-align: middle;
        }

        .section-title {
            font-weight: 600;
        }
    </style>
</head>

<body>

    <!-- Navigation Bar -->
    <nav class="navbar navbar-dark bg-dark px-4 shadow">
        <span class="navbar-brand fw-bold">
            🏏 Cricket Academy Portal
        </span>

        <div>
            <span class="text-white me-3">
                Player:
                <strong><%= user.getFullName() %></strong>
            </span>

            <a href="logout" class="btn btn-outline-danger btn-sm">
                Logout
            </a>
        </div>
    </nav>


    <div class="container my-4">

        <!-- Player Profile -->
        <div class="card p-4 shadow-sm border-0 mb-4">

            <h4 class="mb-3 section-title">
                Player Profile
            </h4>

            <p class="mb-1">
                <strong>Specialization:</strong>
                <%= user.getSpecialization() != null
                        ? user.getSpecialization()
                        : "Not specified" %>
            </p>

            <p class="mb-0">
                <strong>Email:</strong>
                <%= user.getEmail() %>

                <span class="mx-2">|</span>

                <strong>Phone:</strong>
                <%= user.getPhone() %>
            </p>

        </div>


        <!-- Upload Document Section -->
        <div class="card p-4 shadow-sm border-0 mb-4">

            <h4 class="mb-3 section-title">
                Upload Document
            </h4>

            <!-- Upload Success Message -->
            <% if ("success".equals(uploadStatus)) { %>

                <div class="alert alert-success">
                    File uploaded successfully!
                </div>

            <!-- Upload Failed Message -->
            <% } else if ("failed".equals(uploadStatus)) { %>

                <div class="alert alert-danger">
                    File upload failed.

                    <% if (uploadMessage != null && !uploadMessage.isEmpty()) { %>
                        <br>
                        <%= uploadMessage %>
                    <% } %>
                </div>

            <% } %>


            <!-- Upload Form -->
            <form
                action="<%= request.getContextPath() %>/uploadFile"
                method="post"
                enctype="multipart/form-data">

                <div class="mb-3">

                    <label for="document" class="form-label">
                        Select Document
                    </label>

                    <input
                        type="file"
                        class="form-control"
                        id="document"
                        name="document"
                        accept=".pdf,.jpg,.jpeg,.png"
                        required>

                </div>

                <button type="submit" class="btn btn-primary">
                    Upload File
                </button>

            </form>

            <small class="text-muted d-block mt-2">
                Allowed file types: PDF, JPG, JPEG and PNG.
                Maximum size: 10 MB.
            </small>

        </div>


        <!-- Uploaded Documents Section -->
        <div class="card p-4 shadow-sm border-0 mb-4">

            <h4 class="mb-3 section-title">
                Uploaded Documents
            </h4>

            <% if (uploadedFiles == null || uploadedFiles.isEmpty()) { %>

                <div class="alert alert-secondary mb-0">
                    No documents uploaded yet.
                </div>

            <% } else { %>

                <div class="table-responsive">

                    <table class="table table-bordered table-hover align-middle">

                        <thead class="table-success">
                            <tr>
                                <th>File Name</th>
                                <th>File Type</th>
                                <th>Uploaded Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>

                            <% for (UploadedFile file : uploadedFiles) { %>

                                <tr>

                                    <td>
                                        <strong>
                                            <%= file.getOriginalFileName() %>
                                        </strong>
                                    </td>

                                    <td>
                                        <%= file.getFileType() != null
                                                ? file.getFileType()
                                                : "-" %>
                                    </td>

                                    <td>
                                        <%= file.getUploadedDate() != null
                                                ? file.getUploadedDate()
                                                : "-" %>
                                    </td>

                                    <td>
                                        <a
                                            href="<%= request.getContextPath() %>/downloadFile?fileId=<%= file.getFileId() %>"
                                            class="btn btn-success btn-sm">
                                            Download
                                        </a>
                                    </td>

                                </tr>

                            <% } %>

                        </tbody>

                    </table>

                </div>

            <% } %>

        </div>


        <!-- Performance Section -->
        <div class="card p-4 shadow-sm border-0">

            <h4 class="mb-3 section-title">
                Performance &amp; Match Evaluations
            </h4>

            <div class="table-responsive">

                <table class="table table-bordered table-hover align-middle">

                    <thead class="table-primary">
                        <tr>
                            <th>Date</th>
                            <th>Coach</th>
                            <th>Runs (Balls)</th>
                            <th>Strike Rate</th>
                            <th>Wickets (Overs)</th>
                            <th>Fitness (1-10)</th>
                            <th>Coach Feedback</th>
                        </tr>
                    </thead>

                    <tbody>

                        <% if (list == null || list.isEmpty()) { %>

                            <tr>
                                <td colspan="7"
                                    class="text-center text-muted">
                                    No practice/match evaluations yet.
                                </td>
                            </tr>

                        <% } else { %>

                            <% for (Performance p : list) { %>

                                <tr>

                                    <td>
                                        <%= p.getSessionDate() %>
                                    </td>

                                    <td>
                                        <%= p.getCoachName() %>
                                    </td>

                                    <td>
                                        <%= p.getRunsScored() %>
                                        (<%= p.getBallsFaced() %>)
                                    </td>

                                    <td>
                                        <span class="badge bg-success">
                                            <%= String.format(
                                                    "%.1f",
                                                    p.getStrikeRate()
                                                ) %>
                                        </span>
                                    </td>

                                    <td>
                                        <%= p.getWicketsTaken() %>
                                        /
                                        <%= p.getRunsConceded() %>
                                        (<%= p.getOversBowled() %> ov)
                                    </td>

                                    <td>
                                        <strong>
                                            <%= p.getFitnessRating() %>/10
                                        </strong>
                                    </td>

                                    <td>
                                        <%= p.getCoachFeedback() != null
                                                ? p.getCoachFeedback()
                                                : "-" %>
                                    </td>

                                </tr>

                            <% } %>

                        <% } %>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</body>
</html>