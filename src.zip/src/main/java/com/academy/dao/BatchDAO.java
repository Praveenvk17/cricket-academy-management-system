package com.academy.dao;

import com.academy.model.Batch;
import com.academy.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BatchDAO {

    // Add a new batch
    public boolean addBatch(Batch b) throws SQLException {

        String sql = """
                INSERT INTO batches
                (batch_name, coach_id, timing, skill_level, monthly_fee, max_members)
                VALUES (?, ?, ?, ?, ?, ?)
                """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, b.getBatchName());
            ps.setInt(2, b.getCoachId());
            ps.setString(3, b.getTiming());
            ps.setString(4, b.getSkillLevel());
            ps.setDouble(5, b.getMonthlyFee());
            ps.setInt(6, b.getMaxMembers());

            return ps.executeUpdate() > 0;
        }
    }

    // Check whether a batch name already exists
    public boolean batchExists(String batchName) throws SQLException {

        String sql = """
                SELECT COUNT(*)
                FROM batches
                WHERE LOWER(batch_name) = LOWER(?)
                """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, batchName.trim());

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }

        return false;
    }

    // Get all batches with coach name
    public List<Batch> findAll() throws SQLException {

        List<Batch> list = new ArrayList<>();

        String sql = """
                SELECT b.*, u.full_name AS coach_name
                FROM batches b
                JOIN users u ON b.coach_id = u.id
                ORDER BY b.id DESC
                """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                Batch b = new Batch();

                b.setId(rs.getInt("id"));
                b.setBatchName(rs.getString("batch_name"));
                b.setCoachId(rs.getInt("coach_id"));
                b.setCoachName(rs.getString("coach_name"));
                b.setTiming(rs.getString("timing"));
                b.setSkillLevel(rs.getString("skill_level"));
                b.setMonthlyFee(rs.getDouble("monthly_fee"));
                b.setMaxMembers(rs.getInt("max_members"));

                list.add(b);
            }
        }

        return list;
    }

    // Get one batch by ID
    public Batch findById(int batchId) throws SQLException {

        String sql = """
                SELECT b.*, u.full_name AS coach_name
                FROM batches b
                JOIN users u ON b.coach_id = u.id
                WHERE b.id = ?
                """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, batchId);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    Batch b = new Batch();

                    b.setId(rs.getInt("id"));
                    b.setBatchName(rs.getString("batch_name"));
                    b.setCoachId(rs.getInt("coach_id"));
                    b.setCoachName(rs.getString("coach_name"));
                    b.setTiming(rs.getString("timing"));
                    b.setSkillLevel(rs.getString("skill_level"));
                    b.setMonthlyFee(rs.getDouble("monthly_fee"));
                    b.setMaxMembers(rs.getInt("max_members"));

                    return b;
                }
            }
        }

        return null;
    }

    // Update batch details
    public boolean updateBatch(Batch b) throws SQLException {

        String sql = """
                UPDATE batches
                SET batch_name = ?,
                    coach_id = ?,
                    timing = ?,
                    skill_level = ?,
                    monthly_fee = ?,
                    max_members = ?
                WHERE id = ?
                """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, b.getBatchName());
            ps.setInt(2, b.getCoachId());
            ps.setString(3, b.getTiming());
            ps.setString(4, b.getSkillLevel());
            ps.setDouble(5, b.getMonthlyFee());
            ps.setInt(6, b.getMaxMembers());
            ps.setInt(7, b.getId());

            return ps.executeUpdate() > 0;
        }
    }

    // Delete batch by ID
    public boolean deleteBatch(int batchId) throws SQLException {

        String sql = "DELETE FROM batches WHERE id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, batchId);

            return ps.executeUpdate() > 0;
        }
    }

    // Get current active member count in a batch
    public int getCurrentMemberCount(int batchId) throws SQLException {

        String sql = """
                SELECT COUNT(*) AS current_members
                FROM enrollments
                WHERE batch_id = ?
                  AND status = 'ACTIVE'
                """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, batchId);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    return rs.getInt("current_members");
                }
            }
        }

        return 0;
    }

    // Check whether the batch is full
    public boolean isBatchFull(int batchId) throws SQLException {

        String sql = """
                SELECT b.max_members,
                       COUNT(e.id) AS current_members
                FROM batches b
                LEFT JOIN enrollments e
                    ON b.id = e.batch_id
                    AND e.status = 'ACTIVE'
                WHERE b.id = ?
                GROUP BY b.max_members
                """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, batchId);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    int maxMembers = rs.getInt("max_members");
                    int currentMembers = rs.getInt("current_members");

                    return currentMembers >= maxMembers;
                }
            }
        }

        return false;
    }

    // Get available seats in a batch
    public int getAvailableSeats(int batchId) throws SQLException {

        String sql = """
                SELECT b.max_members,
                       COUNT(e.id) AS current_members
                FROM batches b
                LEFT JOIN enrollments e
                    ON b.id = e.batch_id
                    AND e.status = 'ACTIVE'
                WHERE b.id = ?
                GROUP BY b.max_members
                """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, batchId);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    int maxMembers = rs.getInt("max_members");
                    int currentMembers = rs.getInt("current_members");

                    return Math.max(0, maxMembers - currentMembers);
                }
            }
        }

        return 0;
    }
}