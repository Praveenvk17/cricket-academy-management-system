package com.academy.dao;

import com.academy.model.Coach;
import com.academy.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class CoachDAO {

    // Add coach into users table
    public boolean addCoach(Coach coach) {

        String sql = "INSERT INTO users "
                   + "(full_name, email, phone, password, role, specialization, experience) "
                   + "VALUES (?, ?, ?, ?, 'COACH', ?, ?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, coach.getCoachName());
            ps.setString(2, coach.getEmail());
            ps.setString(3, coach.getPhone());

            // Default password for newly added coach
            ps.setString(4, "coach123");

            ps.setString(5, convertSpecialization(coach.getSpecialization()));
            ps.setInt(6, coach.getExperience());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // Get all coaches from users table
    public List<Coach> getAllCoaches() {

        List<Coach> coaches = new ArrayList<>();

        String sql = "SELECT id, full_name, email, phone, "
                   + "specialization, experience "
                   + "FROM users "
                   + "WHERE role = 'COACH' "
                   + "ORDER BY id DESC";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                Coach coach = new Coach();

                coach.setCoachId(rs.getInt("id"));
                coach.setCoachName(rs.getString("full_name"));
                coach.setEmail(rs.getString("email"));
                coach.setPhone(rs.getString("phone"));
                coach.setSpecialization(rs.getString("specialization"));
                coach.setExperience(rs.getInt("experience"));

                coaches.add(coach);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return coaches;
    }

    // Delete coach from users table
    public boolean deleteCoach(int coachId) {

        String sql = "DELETE FROM users "
                   + "WHERE id = ? AND role = 'COACH'";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, coachId);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // Convert specialization text into users table ENUM values
    private String convertSpecialization(String specialization) {

        if (specialization == null) {
            return "GENERAL";
        }

        String value = specialization.toUpperCase();

        if (value.contains("BATTING")) {
            return "BATTING";
        } else if (value.contains("FAST")) {
            return "FAST_BOWLING";
        } else if (value.contains("SPIN")) {
            return "SPIN_BOWLING";
        } else if (value.contains("WICKET")) {
            return "WICKET_KEEPING";
        } else if (value.contains("ALL")) {
            return "ALL_ROUNDER";
        } else {
            return "GENERAL";
        }
    }
}