package com.academy.dao;

import com.academy.model.User;
import com.academy.model.Batch;
import com.academy.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EnrollmentDAO {

    public boolean enrollPlayer(int playerId, int batchId) throws SQLException {

        String sql = """
                INSERT INTO enrollments
                (player_id, batch_id, enrollment_date, status)
                VALUES (?, ?, CURDATE(), 'ACTIVE')
                """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, playerId);
            ps.setInt(2, batchId);

            return ps.executeUpdate() > 0;
        }
    }

    public boolean isAlreadyEnrolled(int playerId, int batchId) throws SQLException {

        String sql = """
                SELECT COUNT(*)
                FROM enrollments
                WHERE player_id = ?
                  AND batch_id = ?
                  AND status = 'ACTIVE'
                """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, playerId);
            ps.setInt(2, batchId);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }

        return false;
    }

    public List<User> getPlayersByCoach(int coachId) throws SQLException {

        List<User> players = new ArrayList<>();

        String sql = """
                SELECT DISTINCT u.*
                FROM users u
                JOIN enrollments e ON u.id = e.player_id
                JOIN batches b ON e.batch_id = b.id
                WHERE b.coach_id = ?
                  AND e.status = 'ACTIVE'
                  AND u.role = 'PLAYER'
                ORDER BY u.full_name ASC
                """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, coachId);

            try (ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {

                    User player = new User(
                            rs.getInt("id"),
                            rs.getString("full_name"),
                            rs.getString("email"),
                            rs.getString("phone"),
                            rs.getString("password"),
                            rs.getString("role"),
                            rs.getString("specialization")
                    );

                    players.add(player);
                }
            }
        }

        return players;
    }

    public Batch getBatchByPlayer(int playerId) throws SQLException {

        String sql = """
                SELECT b.*,
                       u.full_name AS coach_name
                FROM enrollments e
                JOIN batches b ON e.batch_id = b.id
                JOIN users u ON b.coach_id = u.id
                WHERE e.player_id = ?
                  AND e.status = 'ACTIVE'
                ORDER BY e.id DESC
                LIMIT 1
                """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, playerId);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    Batch batch = new Batch();

                    batch.setId(rs.getInt("id"));
                    batch.setBatchName(rs.getString("batch_name"));
                    batch.setCoachId(rs.getInt("coach_id"));
                    batch.setCoachName(rs.getString("coach_name"));
                    batch.setTiming(rs.getString("timing"));
                    batch.setSkillLevel(rs.getString("skill_level"));
                    batch.setMonthlyFee(rs.getDouble("monthly_fee"));
                    batch.setMaxMembers(rs.getInt("max_members"));

                    return batch;
                }
            }
        }

        return null;
    }
}