package com.academy.dao;

import com.academy.model.Performance;
import com.academy.util.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PerformanceDAO {
    public boolean addRecord(Performance p) throws SQLException {
        String sql = "INSERT INTO performance_records(player_id, coach_id, session_date, runs_scored, balls_faced, wickets_taken, overs_bowled, runs_conceded, fitness_rating, coach_feedback) VALUES(?,?,?,?,?,?,?,?,?,?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, p.getPlayerId());
            ps.setInt(2, p.getCoachId());
            ps.setDate(3, p.getSessionDate());
            ps.setInt(4, p.getRunsScored());
            ps.setInt(5, p.getBallsFaced());
            ps.setInt(6, p.getWicketsTaken());
            ps.setDouble(7, p.getOversBowled());
            ps.setInt(8, p.getRunsConceded());
            ps.setInt(9, p.getFitnessRating());
            ps.setString(10, p.getCoachFeedback());
            return ps.executeUpdate() > 0;
        }
    }

    public List<Performance> findByPlayer(int playerId) throws SQLException {
        List<Performance> list = new ArrayList<>();
        String sql = "SELECT pr.*, u.full_name as coach_name FROM performance_records pr " +
                     "JOIN users u ON pr.coach_id = u.id WHERE pr.player_id=? ORDER BY pr.session_date DESC";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, playerId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Performance p = new Performance();
                    p.setId(rs.getInt("id"));
                    p.setPlayerId(rs.getInt("player_id"));
                    p.setCoachName(rs.getString("coach_name"));
                    p.setSessionDate(rs.getDate("session_date"));
                    p.setRunsScored(rs.getInt("runs_scored"));
                    p.setBallsFaced(rs.getInt("balls_faced"));
                    p.setWicketsTaken(rs.getInt("wickets_taken"));
                    p.setOversBowled(rs.getDouble("overs_bowled"));
                    p.setRunsConceded(rs.getInt("runs_conceded"));
                    p.setFitnessRating(rs.getInt("fitness_rating"));
                    p.setCoachFeedback(rs.getString("coach_feedback"));
                    list.add(p);
                }
            }
        }
        return list;
    }
}