package com.academy.dao;

import com.academy.model.UploadedFile;
import com.academy.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UploadedFileDAO {

    // Save uploaded file details into database
    public boolean saveFile(UploadedFile file) {

        String sql = "INSERT INTO uploaded_files "
                   + "(user_id, original_file_name, saved_file_name, file_path, file_type) "
                   + "VALUES (?, ?, ?, ?, ?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, file.getUserId());
            ps.setString(2, file.getOriginalFileName());
            ps.setString(3, file.getSavedFileName());
            ps.setString(4, file.getFilePath());
            ps.setString(5, file.getFileType());

            int rowsInserted = ps.executeUpdate();

            return rowsInserted > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Get one file by file ID
    public UploadedFile getFileById(int fileId) {

        String sql = "SELECT * FROM uploaded_files WHERE file_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, fileId);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    return mapFile(rs);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    // Get all files uploaded by a particular user
    public List<UploadedFile> getFilesByUser(int userId) {

        List<UploadedFile> files = new ArrayList<>();

        String sql = "SELECT * FROM uploaded_files "
                   + "WHERE user_id = ? "
                   + "ORDER BY uploaded_date DESC";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, userId);

            try (ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    files.add(mapFile(rs));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return files;
    }

    // Get all uploaded files - mainly for Admin
    public List<UploadedFile> getAllFiles() {

        List<UploadedFile> files = new ArrayList<>();

        String sql = "SELECT * FROM uploaded_files "
                   + "ORDER BY uploaded_date DESC";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                files.add(mapFile(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return files;
    }

    // Delete file details from database
    public boolean deleteFile(int fileId) {

        String sql = "DELETE FROM uploaded_files WHERE file_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, fileId);

            int rowsDeleted = ps.executeUpdate();

            return rowsDeleted > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Convert ResultSet row into UploadedFile object
    private UploadedFile mapFile(ResultSet rs) throws SQLException {

        UploadedFile file = new UploadedFile();

        file.setFileId(rs.getInt("file_id"));
        file.setUserId(rs.getInt("user_id"));
        file.setOriginalFileName(rs.getString("original_file_name"));
        file.setSavedFileName(rs.getString("saved_file_name"));
        file.setFilePath(rs.getString("file_path"));
        file.setFileType(rs.getString("file_type"));
        file.setUploadedDate(rs.getTimestamp("uploaded_date"));

        return file;
    }
}