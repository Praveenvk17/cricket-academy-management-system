package com.academy.model;

public class Batch {

    private int id;
    private int coachId;
    private int maxMembers;

    private String batchName;
    private String coachName;
    private String timing;
    private String skillLevel;

    private double monthlyFee;

    // Get Batch ID
    public int getId() {
        return id;
    }

    // Set Batch ID
    public void setId(int id) {
        this.id = id;
    }

    // Get Coach ID
    public int getCoachId() {
        return coachId;
    }

    // Set Coach ID
    public void setCoachId(int coachId) {
        this.coachId = coachId;
    }

    // Get Maximum Members
    public int getMaxMembers() {
        return maxMembers;
    }

    // Set Maximum Members
    public void setMaxMembers(int maxMembers) {
        this.maxMembers = maxMembers;
    }

    // Get Batch Name
    public String getBatchName() {
        return batchName;
    }

    // Set Batch Name
    public void setBatchName(String batchName) {
        this.batchName = batchName;
    }

    // Get Coach Name
    public String getCoachName() {
        return coachName;
    }

    // Set Coach Name
    public void setCoachName(String coachName) {
        this.coachName = coachName;
    }

    // Get Timing
    public String getTiming() {
        return timing;
    }

    // Set Timing
    public void setTiming(String timing) {
        this.timing = timing;
    }

    // Get Skill Level
    public String getSkillLevel() {
        return skillLevel;
    }

    // Set Skill Level
    public void setSkillLevel(String skillLevel) {
        this.skillLevel = skillLevel;
    }

    // Get Monthly Fee
    public double getMonthlyFee() {
        return monthlyFee;
    }

    // Set Monthly Fee
    public void setMonthlyFee(double monthlyFee) {
        this.monthlyFee = monthlyFee;
    }
}