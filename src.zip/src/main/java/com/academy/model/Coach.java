package com.academy.model;

public class Coach {

    private int coachId;
    private String coachName;
    private String specialization;
    private int experience;
    private String phone;
    private String email;

    public Coach() {
    }

    public Coach(String coachName, String specialization,
                 int experience, String phone, String email) {
        this.coachName = coachName;
        this.specialization = specialization;
        this.experience = experience;
        this.phone = phone;
        this.email = email;
    }

    public int getCoachId() {
        return coachId;
    }

    public void setCoachId(int coachId) {
        this.coachId = coachId;
    }

    public String getCoachName() {
        return coachName;
    }

    public void setCoachName(String coachName) {
        this.coachName = coachName;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public int getExperience() {
        return experience;
    }

    public void setExperience(int experience) {
        this.experience = experience;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}