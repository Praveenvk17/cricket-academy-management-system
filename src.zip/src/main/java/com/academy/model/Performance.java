package com.academy.model;

import java.sql.Date;

public class Performance {
    private int id, playerId, coachId, runsScored, ballsFaced, wicketsTaken, runsConceded, fitnessRating;
    private double oversBowled;
    private String playerName, coachName, coachFeedback;
    private Date sessionDate;

    public double getStrikeRate() {
        return (ballsFaced > 0) ? ((double) runsScored / ballsFaced) * 100 : 0.0;
    }

    public double getEconomyRate() {
        return (oversBowled > 0) ? ((double) runsConceded / oversBowled) : 0.0;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getPlayerId() { return playerId; }
    public void setPlayerId(int playerId) { this.playerId = playerId; }
    public int getCoachId() { return coachId; }
    public void setCoachId(int coachId) { this.coachId = coachId; }
    public int getRunsScored() { return runsScored; }
    public void setRunsScored(int runsScored) { this.runsScored = runsScored; }
    public int getBallsFaced() { return ballsFaced; }
    public void setBallsFaced(int ballsFaced) { this.ballsFaced = ballsFaced; }
    public int getWicketsTaken() { return wicketsTaken; }
    public void setWicketsTaken(int wicketsTaken) { this.wicketsTaken = wicketsTaken; }
    public int getRunsConceded() { return runsConceded; }
    public void setRunsConceded(int runsConceded) { this.runsConceded = runsConceded; }
    public int getFitnessRating() { return fitnessRating; }
    public void setFitnessRating(int fitnessRating) { this.fitnessRating = fitnessRating; }
    public double getOversBowled() { return oversBowled; }
    public void setOversBowled(double oversBowled) { this.oversBowled = oversBowled; }
    public String getPlayerName() { return playerName; }
    public void setPlayerName(String playerName) { this.playerName = playerName; }
    public String getCoachName() { return coachName; }
    public void setCoachName(String coachName) { this.coachName = coachName; }
    public String getCoachFeedback() { return coachFeedback; }
    public void setCoachFeedback(String coachFeedback) { this.coachFeedback = coachFeedback; }
    public Date getSessionDate() { return sessionDate; }
    public void setSessionDate(Date sessionDate) { this.sessionDate = sessionDate; }
}