package com.academy.model;

import java.sql.Timestamp;

public class UploadedFile {

    private int fileId;
    private int userId;
    private String originalFileName;
    private String savedFileName;
    private String filePath;
    private String fileType;
    private Timestamp uploadedDate;

    // Default constructor
    public UploadedFile() {
    }

    // Constructor without fileId and uploadedDate
    public UploadedFile(int userId,
                        String originalFileName,
                        String savedFileName,
                        String filePath,
                        String fileType) {

        this.userId = userId;
        this.originalFileName = originalFileName;
        this.savedFileName = savedFileName;
        this.filePath = filePath;
        this.fileType = fileType;
    }

    // Getter and Setter for fileId
    public int getFileId() {
        return fileId;
    }

    public void setFileId(int fileId) {
        this.fileId = fileId;
    }

    // Getter and Setter for userId
    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    // Getter and Setter for originalFileName
    public String getOriginalFileName() {
        return originalFileName;
    }

    public void setOriginalFileName(String originalFileName) {
        this.originalFileName = originalFileName;
    }

    // Getter and Setter for savedFileName
    public String getSavedFileName() {
        return savedFileName;
    }

    public void setSavedFileName(String savedFileName) {
        this.savedFileName = savedFileName;
    }

    // Getter and Setter for filePath
    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    // Getter and Setter for fileType
    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    // Getter and Setter for uploadedDate
    public Timestamp getUploadedDate() {
        return uploadedDate;
    }

    public void setUploadedDate(Timestamp uploadedDate) {
        this.uploadedDate = uploadedDate;
    }
}