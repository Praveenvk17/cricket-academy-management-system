package com.academy.servlet;

import com.academy.dao.CoachDAO;
import com.academy.model.Coach;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/addCoach")
public class AddCoachServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        String coachName = request.getParameter("coachName");
        String specialization = request.getParameter("specialization");
        int experience = Integer.parseInt(request.getParameter("experience"));
        String phone = request.getParameter("phone");
        String email = request.getParameter("email");

        Coach coach = new Coach(
                coachName,
                specialization,
                experience,
                phone,
                email
        );

        CoachDAO coachDAO = new CoachDAO();
        boolean success = coachDAO.addCoach(coach);

        if (success) {
            response.sendRedirect("coach-management.jsp");
        } else {
            response.sendRedirect("coach-management.jsp?error=failed");
        }
    }
}