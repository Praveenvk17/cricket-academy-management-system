package com.academy.servlet;

import com.academy.dao.BatchDAO;
import com.academy.dao.EnrollmentDAO;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/assign-player")
public class AssignPlayerServlet extends HttpServlet {

    private final EnrollmentDAO enrollmentDAO = new EnrollmentDAO();
    private final BatchDAO batchDAO = new BatchDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String playerIdParam = request.getParameter("playerId");
        String batchIdParam = request.getParameter("batchId");

        try {

            if (playerIdParam == null || batchIdParam == null) {
                response.sendRedirect("admin-dashboard.jsp?error=invalid");
                return;
            }

            int playerId = Integer.parseInt(playerIdParam);
            int batchId = Integer.parseInt(batchIdParam);

            // Check whether batch is full
            if (batchDAO.isBatchFull(batchId)) {
                response.sendRedirect("admin-dashboard.jsp?error=batchFull");
                return;
            }

            // Check whether player is already assigned
            if (enrollmentDAO.isAlreadyEnrolled(playerId, batchId)) {
                response.sendRedirect("admin-dashboard.jsp?error=alreadyEnrolled");
                return;
            }

            // Assign player to batch
            boolean success = enrollmentDAO.enrollPlayer(playerId, batchId);

            if (success) {
                response.sendRedirect("admin-dashboard.jsp?success=playerAssigned");
            } else {
                response.sendRedirect("admin-dashboard.jsp?error=assignFailed");
            }

        } catch (NumberFormatException e) {

            response.sendRedirect("admin-dashboard.jsp?error=invalid");

        } catch (Exception e) {

            e.printStackTrace();
            response.sendRedirect("admin-dashboard.jsp?error=serverError");
        }
    }
}