package com.academy.servlet;

import com.academy.dao.BatchDAO;
import com.academy.model.Batch;
import com.academy.model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/add-batch")
public class BatchServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=UTF-8");

        try {

            HttpSession session = req.getSession(false);

            User user = null;

            if (session != null) {
                user = (User) session.getAttribute("user");
            }

            if (user == null || !"ADMIN".equalsIgnoreCase(user.getRole())) {
                resp.sendRedirect("login.jsp");
                return;
            }

            String batchName = req.getParameter("batchName");
            String coachIdValue = req.getParameter("coachId");
            String timing = req.getParameter("timing");
            String skillLevel = req.getParameter("skillLevel");
            String monthlyFeeValue = req.getParameter("monthlyFee");
            String maxMembersValue = req.getParameter("maxMembers");

            // Validate empty fields
            if (batchName == null || batchName.trim().isEmpty()) {
                showError(resp, "Batch Name is required.");
                return;
            }

            if (coachIdValue == null || coachIdValue.trim().isEmpty()) {
                showError(resp, "Coach ID is required.");
                return;
            }

            if (timing == null || timing.trim().isEmpty()) {
                showError(resp, "Timing is required.");
                return;
            }

            if (skillLevel == null || skillLevel.trim().isEmpty()) {
                showError(resp, "Skill Level is required.");
                return;
            }

            if (monthlyFeeValue == null || monthlyFeeValue.trim().isEmpty()) {
                showError(resp, "Monthly Fee is required.");
                return;
            }

            if (maxMembersValue == null || maxMembersValue.trim().isEmpty()) {
                showError(resp, "Maximum Members is required.");
                return;
            }

            batchName = batchName.trim();
            timing = timing.trim();
            skillLevel = skillLevel.trim();

            int coachId = Integer.parseInt(coachIdValue.trim());
            double monthlyFee = Double.parseDouble(monthlyFeeValue.trim());
            int maxMembers = Integer.parseInt(maxMembersValue.trim());

            // Validate maximum capacity
            if (maxMembers < 1 || maxMembers > 15) {
                showError(resp, "Maximum Members must be between 1 and 15.");
                return;
            }

            if (monthlyFee < 0) {
                showError(resp, "Monthly Fee cannot be negative.");
                return;
            }

            BatchDAO dao = new BatchDAO();

            // Prevent duplicate batch names
            if (dao.batchExists(batchName)) {
                showError(resp, "Batch name already exists. Please use a different name.");
                return;
            }

            Batch batch = new Batch();

            batch.setBatchName(batchName);
            batch.setCoachId(coachId);
            batch.setTiming(timing);
            batch.setSkillLevel(skillLevel);
            batch.setMonthlyFee(monthlyFee);
            batch.setMaxMembers(maxMembers);

            boolean success = dao.addBatch(batch);

            if (success) {

                resp.sendRedirect(
                        req.getContextPath()
                        + "/admin-dashboard.jsp?success=Batch+created+successfully"
                );

            } else {

                showError(resp, "Batch was not created. Please try again.");
            }

        } catch (NumberFormatException e) {

            showError(
                    resp,
                    "Please enter valid numeric values for Coach ID, Monthly Fee and Maximum Members."
            );

        } catch (Exception e) {

            e.printStackTrace();

            showError(
                    resp,
                    "Something went wrong while creating the batch. Please check the server console."
            );
        }
    }

    private void showError(HttpServletResponse resp, String message)
            throws IOException {

        resp.setContentType("text/html;charset=UTF-8");

        resp.getWriter().println("""
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset="UTF-8">
                    <title>Batch Error</title>
                    <style>
                        body {
                            font-family: Arial, sans-serif;
                            background: #f4f6f9;
                            text-align: center;
                            padding-top: 100px;
                        }

                        .box {
                            background: white;
                            display: inline-block;
                            padding: 35px;
                            border-radius: 12px;
                            box-shadow: 0 0 12px rgba(0, 0, 0, 0.1);
                            max-width: 500px;
                        }

                        h2 {
                            color: #dc2626;
                        }

                        p {
                            color: #555;
                        }

                        a {
                            display: inline-block;
                            margin-top: 20px;
                            padding: 10px 18px;
                            background: #1e3a8a;
                            color: white;
                            text-decoration: none;
                            border-radius: 6px;
                        }
                    </style>
                </head>
                <body>
                    <div class="box">
                """);

        resp.getWriter().println("<h2>Batch Creation Error</h2>");
        resp.getWriter().println("<p>" + message + "</p>");
        resp.getWriter().println("""
                        <a href="admin-dashboard.jsp">Back to Dashboard</a>
                    </div>
                </body>
                </html>
                """);
    }
}