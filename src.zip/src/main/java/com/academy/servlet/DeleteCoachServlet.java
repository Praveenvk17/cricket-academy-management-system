package com.academy.servlet;

import com.academy.dao.CoachDAO;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/deleteCoach")
public class DeleteCoachServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        int coachId = Integer.parseInt(
                request.getParameter("coachId")
        );

        CoachDAO coachDAO = new CoachDAO();
        coachDAO.deleteCoach(coachId);

        response.sendRedirect("coach-management.jsp");
    }
}