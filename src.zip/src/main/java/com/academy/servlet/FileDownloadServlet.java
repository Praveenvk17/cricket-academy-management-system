package com.academy.servlet;

import com.academy.dao.UploadedFileDAO;
import com.academy.model.UploadedFile;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;

@WebServlet("/downloadFile")
public class FileDownloadServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private UploadedFileDAO uploadedFileDAO = new UploadedFileDAO();

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        String fileIdParam = request.getParameter("fileId");

        if (fileIdParam == null || fileIdParam.trim().isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST,
                    "File ID is missing");
            return;
        }

        try {
            int fileId = Integer.parseInt(fileIdParam);

            UploadedFile uploadedFile =
                    uploadedFileDAO.getFileById(fileId);

            if (uploadedFile == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND,
                        "File not found");
                return;
            }

            File file = new File(uploadedFile.getFilePath());

            if (!file.exists() || !file.isFile()) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND,
                        "Physical file not found");
                return;
            }

            response.setContentType(
                    uploadedFile.getFileType() != null
                            ? uploadedFile.getFileType()
                            : "application/octet-stream"
            );

            response.setContentLengthLong(file.length());

            response.setHeader(
                    "Content-Disposition",
                    "attachment; filename=\"" +
                            uploadedFile.getOriginalFileName() + "\""
            );

            try (FileInputStream inputStream =
                         new FileInputStream(file);
                 OutputStream outputStream =
                         response.getOutputStream()) {

                byte[] buffer = new byte[4096];
                int bytesRead;

                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    outputStream.write(buffer, 0, bytesRead);
                }
            }

        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST,
                    "Invalid file ID");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    "Unable to download file");
        }
    }
}