package com.academy.servlet;

import com.academy.dao.UploadedFileDAO;
import com.academy.model.UploadedFile;
import com.academy.model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;

import java.io.File;
import java.io.IOException;

@WebServlet("/uploadFile")
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 2,   // 2 MB
    maxFileSize = 1024 * 1024 * 10,        // 10 MB
    maxRequestSize = 1024 * 1024 * 50      // 50 MB
)
public class FileUploadServlet extends HttpServlet {

    private static final String UPLOAD_DIR = "uploads";

    private final UploadedFileDAO uploadedFileDAO = new UploadedFileDAO();

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        // Check existing login session
        HttpSession session = request.getSession(false);

        User currentUser = null;

        if (session != null) {
            currentUser = (User) session.getAttribute("user");
        }

        // If user is not logged in, redirect to login page
        if (currentUser == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        // Decide dashboard based on user role
        String redirectTarget;

        if ("ADMIN".equalsIgnoreCase(currentUser.getRole())) {
            redirectTarget = "admin-dashboard.jsp";
        } else if ("COACH".equalsIgnoreCase(currentUser.getRole())) {
            redirectTarget = "coach-dashboard.jsp";
        } else {
            redirectTarget = "player-dashboard.jsp";
        }

        try {
            // Get uploaded file from HTML input name="document"
            Part filePart = request.getPart("document");

            // Check whether file is selected
            if (filePart == null || filePart.getSize() == 0) {
                response.sendRedirect(
                    redirectTarget + "?upload=failed&message=Please select a file"
                );
                return;
            }

            // Get original file name
            String originalFileName = filePart.getSubmittedFileName();

            if (originalFileName == null || originalFileName.trim().isEmpty()) {
                response.sendRedirect(
                    redirectTarget + "?upload=failed&message=Invalid file name"
                );
                return;
            }

            // Extract only the file name, not the complete client path
            originalFileName = new File(originalFileName)
                    .getName();

            // Get file extension
            String fileExtension = "";

            int lastDotIndex = originalFileName.lastIndexOf(".");

            if (lastDotIndex > 0) {
                fileExtension = originalFileName
                        .substring(lastDotIndex)
                        .toLowerCase();
            }

            // Allow only selected file types
            if (!fileExtension.equals(".pdf")
                    && !fileExtension.equals(".jpg")
                    && !fileExtension.equals(".jpeg")
                    && !fileExtension.equals(".png")) {

                response.sendRedirect(
                    redirectTarget
                    + "?upload=failed&message=Only PDF, JPG, JPEG and PNG files are allowed"
                );
                return;
            }

            // Get deployed application path
            String applicationPath = request
                    .getServletContext()
                    .getRealPath("");

            // Create uploads folder path
            String uploadFilePath = applicationPath
                    + File.separator
                    + UPLOAD_DIR;

            File uploadFolder = new File(uploadFilePath);

            // Create folder if it does not exist
            if (!uploadFolder.exists()) {
                boolean folderCreated = uploadFolder.mkdirs();

                if (!folderCreated) {
                    response.sendRedirect(
                        redirectTarget
                        + "?upload=failed&message=Unable to create upload folder"
                    );
                    return;
                }
            }

            // Create unique file name
            String uniqueFileName = System.currentTimeMillis()
                    + "_"
                    + originalFileName;

            // Complete path where file will be saved
            String savedFilePath = uploadFilePath
                    + File.separator
                    + uniqueFileName;

            // Save actual file into uploads folder
            filePart.write(savedFilePath);

            // Create UploadedFile model object
            UploadedFile uploadedFile = new UploadedFile();

            uploadedFile.setUserId(currentUser.getId());
            uploadedFile.setOriginalFileName(originalFileName);
            uploadedFile.setSavedFileName(uniqueFileName);
            uploadedFile.setFilePath(savedFilePath);
            uploadedFile.setFileType(filePart.getContentType());

            // Save file details into database
            boolean savedInDatabase = uploadedFileDAO
                    .saveFile(uploadedFile);

            if (savedInDatabase) {

                System.out.println(
                    "File uploaded successfully: " + uniqueFileName
                );

                response.sendRedirect(
                    redirectTarget + "?upload=success"
                );

            } else {

                // If database saving fails, delete the uploaded physical file
                File uploadedPhysicalFile = new File(savedFilePath);

                if (uploadedPhysicalFile.exists()) {
                    uploadedPhysicalFile.delete();
                }

                response.sendRedirect(
                    redirectTarget
                    + "?upload=failed&message=Unable to save file details"
                );
            }

        } catch (Exception e) {

            e.printStackTrace();

            response.sendRedirect(
                redirectTarget + "?upload=failed"
            );
        }
    }
}