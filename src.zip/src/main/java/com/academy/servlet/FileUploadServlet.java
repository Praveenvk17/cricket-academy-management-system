package com.academy.servlet;

import com.academy.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.File;
import java.io.IOException;

@WebServlet("/uploadFile")
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 2,  // 2MB
    maxFileSize = 1024 * 1024 * 10,       // 10MB
    maxRequestSize = 1024 * 1024 * 50     // 50MB
)
public class FileUploadServlet extends HttpServlet {
    private static final String UPLOAD_DIR = "uploads";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User currentUser = (session != null) ? (User) session.getAttribute("user") : null;

        // User login panni irukkura role-ku etha maari dashboard redirect target
        String redirectTarget = "login.jsp";
        if (currentUser != null) {
            if ("ADMIN".equalsIgnoreCase(currentUser.getRole())) {
                redirectTarget = "admin-dashboard.jsp";
            } else if ("COACH".equalsIgnoreCase(currentUser.getRole())) {
                redirectTarget = "coach-dashboard.jsp";
            } else {
                redirectTarget = "player-dashboard.jsp";
            }
        }
        
        String applicationPath = request.getServletContext().getRealPath("");
        String uploadFilePath = applicationPath + File.separator + UPLOAD_DIR;

        File uploadFolder = new File(uploadFilePath);
        if (!uploadFolder.exists()) {
            uploadFolder.mkdirs();
        }

        try {
            Part filePart = request.getPart("document");
            if (filePart != null && filePart.getSize() > 0) {
                String originalFileName = filePart.getSubmittedFileName();
                String uniqueFileName = System.currentTimeMillis() + "_" + originalFileName;
                
                filePart.write(uploadFilePath + File.separator + uniqueFileName);
                System.out.println("File uploaded successfully: " + uniqueFileName);
                
                response.sendRedirect(redirectTarget + "?upload=success");
                return;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        response.sendRedirect(redirectTarget + "?upload=failed");
    }
}