package com.academy.servlet;

import com.academy.dao.UserDAO;
import com.academy.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String email = req.getParameter("email");
        String password = req.getParameter("password");
        try {
            User user = new UserDAO().login(email, password);
            if (user != null) {
                HttpSession session = req.getSession();
                session.setAttribute("user", user);
                if ("ADMIN".equals(user.getRole())) {
                    resp.sendRedirect("admin-dashboard.jsp");
                } else if ("COACH".equals(user.getRole())) {
                    resp.sendRedirect("coach-dashboard.jsp");
                } else {
                    resp.sendRedirect("player-dashboard.jsp");
                }
            } else {
                req.setAttribute("error", "Invalid Email or Password");
                req.getRequestDispatcher("login.jsp").forward(req, resp);
            }
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }
}