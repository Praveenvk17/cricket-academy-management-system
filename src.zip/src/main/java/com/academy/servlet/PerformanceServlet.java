package com.academy.servlet;

import com.academy.dao.PerformanceDAO;
import com.academy.model.Performance;
import com.academy.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.Date;

@WebServlet("/add-performance")
public class PerformanceServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User user = (User) req.getSession().getAttribute("user");
        if (user == null || (!"COACH".equals(user.getRole()) && !"ADMIN".equals(user.getRole()))) {
            resp.sendRedirect("login.jsp");
            return;
        }

        Performance p = new Performance();
        p.setPlayerId(Integer.parseInt(req.getParameter("playerId")));
        p.setCoachId(user.getId());
        p.setSessionDate(Date.valueOf(req.getParameter("sessionDate")));
        p.setRunsScored(Integer.parseInt(req.getParameter("runsScored")));
        p.setBallsFaced(Integer.parseInt(req.getParameter("ballsFaced")));
        p.setWicketsTaken(Integer.parseInt(req.getParameter("wicketsTaken")));
        p.setOversBowled(Double.parseDouble(req.getParameter("oversBowled")));
        p.setRunsConceded(Integer.parseInt(req.getParameter("runsConceded")));
        p.setFitnessRating(Integer.parseInt(req.getParameter("fitnessRating")));
        p.setCoachFeedback(req.getParameter("coachFeedback"));

        try {
            new PerformanceDAO().addRecord(p);
            resp.sendRedirect("coach-dashboard.jsp?success=Performance evaluated successfully");
        } catch (Exception e) {
            resp.sendRedirect("coach-dashboard.jsp?error=Failed to record performance");
        }
    }
}