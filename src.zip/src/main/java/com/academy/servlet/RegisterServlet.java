package com.academy.servlet;

import com.academy.dao.UserDAO;
import com.academy.model.User;
import com.academy.util.EmailUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User u = new User();
        u.setFullName(req.getParameter("fullName"));
        u.setEmail(req.getParameter("email"));
        u.setPhone(req.getParameter("phone"));
        u.setPassword(req.getParameter("password"));
        u.setRole("PLAYER");
        u.setSpecialization(req.getParameter("specialization"));

        try {
            if (new UserDAO().register(u)) {
                // Registration success aana udane background-la email anuppum
                try {
                    EmailUtil.sendRegistrationEmail(u.getEmail(), u.getFullName(), u.getRole());
                } catch (Exception ex) {
                    System.err.println("Email trigger failed: " + ex.getMessage());
                }
                
                resp.sendRedirect("login.jsp?registered=true");
            } else {
                req.setAttribute("error", "Registration failed");
                req.getRequestDispatcher("register.jsp").forward(req, resp);
            }
        } catch (Exception e) {
            req.setAttribute("error", "Email already exists");
            req.getRequestDispatcher("register.jsp").forward(req, resp);
        }
    }
}