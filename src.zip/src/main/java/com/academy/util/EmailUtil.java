package com.academy.util;

import java.util.Properties;
import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;

public class EmailUtil {

    // Neenga use panra Gmail ID & Google 16-digit App Password inga kudunga
    private static final String SENDER_EMAIL = "your-own-email@gmail.com";
    private static final String APP_PASSWORD = "your-app-password";

    public static boolean sendRegistrationEmail(String recipientEmail, String studentName, String role) {
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(SENDER_EMAIL, APP_PASSWORD);
            }
        });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(SENDER_EMAIL, "Cricket Academy Support"));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientEmail));
            message.setSubject("Registration Successful - Cricket Academy");

            String content = "Hello " + studentName + ",\n\n"
                    + "Welcome to Cricket Academy Management System!\n"
                    + "Your account has been registered successfully as: " + role + ".\n\n"
                    + "You can now login and check your training schedules and batches.\n\n"
                    + "Regards,\nCricket Academy Team";

            message.setText(content);
            Transport.send(message);
            System.out.println("Email sent successfully to: " + recipientEmail);
            return true;
        } catch (Exception e) {
            System.err.println("Failed to send email: " + e.getMessage());
            return false;
        }
    }
}