package com.academy.util;

import com.academy.model.User;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ReportService {

    // 1. Stream API: Group users by Role (Admin, Coach, Player) and return counts
    public Map<String, Long> getUserRoleCounts(List<User> users) {
        return users.stream()
                .filter(u -> u.getRole() != null)
                .collect(Collectors.groupingBy(User::getRole, Collectors.counting()));
    }

    // 2. Stream API: Filter only unique player specializations
    public List<String> getUniqueSpecializations(List<User> users) {
        return users.stream()
                .map(User::getSpecialization)
                .filter(spec -> spec != null && !spec.trim().isEmpty())
                .distinct()
                .sorted()
                .collect(Collectors.toList());
    }

    // 3. Stream API: Count total players
    public long getTotalPlayerCount(List<User> users) {
        return users.stream()
                .filter(u -> "PLAYER".equalsIgnoreCase(u.getRole()))
                .count();
    }
}