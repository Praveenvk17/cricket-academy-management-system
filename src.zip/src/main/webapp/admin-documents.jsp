<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<%@ page import="com.academy.model.User" %>
<%@ page import="com.academy.dao.UploadedFileDAO" %>
<%@ page import="com.academy.model.UploadedFile" %>
<%@ page import="java.util.List" %>

<%
    User admin = (User) session.getAttribute("user");

    if (admin == null || !"ADMIN".equalsIgnoreCase(admin.getRole())) {
        response.sendRedirect("login.jsp");
        return;
    }

    UploadedFileDAO uploadedFileDAO = new UploadedFileDAO();
    List<UploadedFile> uploadedFiles = uploadedFileDAO.getAllFiles();
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Player Documents | Cricket Academy</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">

    <style>
        body {
            background: #f4f7f6;
            font-family: Arial, sans-serif;
        }

        .navbar {
            background: #198754;
        }

        .page-title {
            color: #198754;
            font-weight: bold;
        }

        .card {
            border-radius: 15px;
        }

        .table th {
            background: #198754;
            color: white;
        }
    </style>
</head>

<body>

<nav class="navbar navbar-dark">
    <div class="container">
        <a class="navbar-brand fw-bold" href="admin-dashboard.jsp">
            Cricket Academy Management
        </a>

        <a href="admin-dashboard.jsp" class="btn btn-light btn-sm">
            Back to Dashboard
        </a>
    </div>
</nav>

<div class="container mt-4 mb-5">

    <h2 class="page-title mb-4">Player Uploaded Documents</h2>

    <div class="card shadow-sm border-0 p-4">

        <% if (uploadedFiles == null || uploadedFiles.isEmpty()) { %>

            <div class="alert alert-info mb-0">
                No player documents uploaded yet.
            </div>

        <% } else { %>

            <div class="table-responsive">
                <table class="table table-bordered table-hover align-middle">

                    <thead>
                        <tr>
                            <th>S.No</th>
                            <th>Player ID</th>
                            <th>File Name</th>
                            <th>File Type</th>
                            <th>Uploaded Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        <%
                            int count = 1;

                            for (UploadedFile file : uploadedFiles) {
                        %>

                        <tr>
                            <td><%= count++ %></td>

                            <td>
                                <%= file.getUserId() %>
                            </td>

                            <td>
                                <strong>
                                    <%= file.getOriginalFileName() %>
                                </strong>
                            </td>

                            <td>
                                <%= file.getFileType() != null
                                        ? file.getFileType()
                                        : "-" %>
                            </td>

                            <td>
                                <%= file.getUploadedDate() != null
                                        ? file.getUploadedDate()
                                        : "-" %>
                            </td>

                            <td>
                                <a href="<%= request.getContextPath() %>/downloadFile?fileId=<%= file.getFileId() %>"
                                   class="btn btn-success btn-sm">
                                    Download
                                </a>
                            </td>
                        </tr>

                        <%
                            }
                        %>
                    </tbody>

                </table>
            </div>

        <% } %>

    </div>

</div>

</body>
</html>