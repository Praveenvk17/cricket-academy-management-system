<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<%@ page import="com.academy.model.User" %>
<%@ page import="com.academy.dao.EnrollmentDAO" %>
<%@ page import="java.util.List" %>

<%
    User user = (User) session.getAttribute("user");

    if (user == null ||
        (!"COACH".equalsIgnoreCase(user.getRole()) &&
         !"ADMIN".equalsIgnoreCase(user.getRole()))) {

        response.sendRedirect("login.jsp");
        return;
    }

    EnrollmentDAO enrollmentDAO = new EnrollmentDAO();

    List<User> players = enrollmentDAO.getPlayersByCoach(user.getId());
%>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Coach Evaluation Portal</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
          rel="stylesheet">

</head>

<body class="bg-light">

<nav class="navbar navbar-dark bg-success px-4 shadow">

    <span class="navbar-brand fw-bold">
        🏏 Coach Assessment Panel
    </span>

    <div>

        <span class="text-white me-3">
            Coach:
            <strong><%= user.getFullName() %></strong>
        </span>

        <a href="logout"
           class="btn btn-outline-light btn-sm">
            Logout
        </a>

    </div>

</nav>


<div class="container my-4">

    <% if (request.getParameter("success") != null) { %>

        <div class="alert alert-success">
            <%= request.getParameter("success") %>
        </div>

    <% } %>


    <!-- Assigned Players -->

    <div class="card p-4 shadow-sm border-0 mb-4">

        <h4 class="mb-3">
            👥 My Assigned Players
        </h4>

        <% if (players.isEmpty()) { %>

            <div class="alert alert-info mb-0">
                No players are currently assigned to your batches.
            </div>

        <% } else { %>

            <div class="table-responsive">

                <table class="table table-hover align-middle">

                    <thead class="table-success">

                    <tr>
                        <th>Player Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Specialization</th>
                    </tr>

                    </thead>

                    <tbody>

                    <% for (User p : players) { %>

                    <tr>

                        <td>
                            <strong>
                                <%= p.getFullName() %>
                            </strong>
                        </td>

                        <td>
                            <%= p.getEmail() %>
                        </td>

                        <td>
                            <%= p.getPhone() %>
                        </td>

                        <td>
                            <span class="badge bg-secondary">
                                <%= p.getSpecialization() %>
                            </span>
                        </td>

                    </tr>

                    <% } %>

                    </tbody>

                </table>

            </div>

        <% } %>

    </div>


    <!-- Player Evaluation -->

    <div class="card p-4 shadow-sm border-0">

        <h4 class="mb-3">
            Evaluate Player Performance
        </h4>

        <form action="add-performance" method="post">

            <div class="row g-3">

                <div class="col-md-6">

                    <label class="form-label">
                        Select Player
                    </label>

                    <select name="playerId"
                            class="form-select"
                            required>

                        <option value="">
                            -- Choose Player --
                        </option>

                        <% for (User p : players) { %>

                        <option value="<%= p.getId() %>">
                            <%= p.getFullName() %>
                            (<%= p.getSpecialization() %>)
                        </option>

                        <% } %>

                    </select>

                </div>


                <div class="col-md-6">

                    <label class="form-label">
                        Session Date
                    </label>

                    <input type="date"
                           name="sessionDate"
                           class="form-control"
                           required>

                </div>


                <div class="col-md-3">

                    <label class="form-label">
                        Runs Scored
                    </label>

                    <input type="number"
                           name="runsScored"
                           class="form-control"
                           value="0"
                           min="0"
                           required>

                </div>


                <div class="col-md-3">

                    <label class="form-label">
                        Balls Faced
                    </label>

                    <input type="number"
                           name="ballsFaced"
                           class="form-control"
                           value="0"
                           min="0"
                           required>

                </div>


                <div class="col-md-2">

                    <label class="form-label">
                        Wickets Taken
                    </label>

                    <input type="number"
                           name="wicketsTaken"
                           class="form-control"
                           value="0"
                           min="0"
                           required>

                </div>


                <div class="col-md-2">

                    <label class="form-label">
                        Overs Bowled
                    </label>

                    <input type="number"
                           step="0.1"
                           name="oversBowled"
                           class="form-control"
                           value="0.0"
                           min="0"
                           required>

                </div>


                <div class="col-md-2">

                    <label class="form-label">
                        Runs Conceded
                    </label>

                    <input type="number"
                           name="runsConceded"
                           class="form-control"
                           value="0"
                           min="0"
                           required>

                </div>


                <div class="col-md-3">

                    <label class="form-label">
                        Fitness Rating (1-10)
                    </label>

                    <input type="number"
                           name="fitnessRating"
                           min="1"
                           max="10"
                           class="form-control"
                           value="8"
                           required>

                </div>


                <div class="col-md-9">

                    <label class="form-label">
                        Coach Feedback / Drill Notes
                    </label>

                    <input type="text"
                           name="coachFeedback"
                           class="form-control"
                           placeholder="Good line & length, work on backfoot play"
                           required>

                </div>


                <div class="col-12">

                    <button type="submit"
                            class="btn btn-success px-4 py-2">

                        Submit Evaluation

                    </button>

                </div>

            </div>

        </form>

    </div>

</div>

</body>
</html>