<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<%@ page import="com.academy.model.User" %>
<%@ page import="com.academy.model.Coach" %>
<%@ page import="com.academy.dao.CoachDAO" %>
<%@ page import="java.util.List" %>

<%
    User admin = (User) session.getAttribute("user");

    if (admin == null || !"ADMIN".equalsIgnoreCase(admin.getRole())) {
        response.sendRedirect("login.jsp");
        return;
    }

    CoachDAO coachDAO = new CoachDAO();
    List<Coach> coaches = coachDAO.getAllCoaches();
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Coach Management - Cricket Academy</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
        rel="stylesheet">
</head>

<body class="bg-light">

<nav class="navbar navbar-dark bg-success px-4 shadow">
    <span class="navbar-brand fw-bold">
        🏏 Cricket Academy - Coach Management
    </span>

    <div>
        <span class="text-white me-3">
            Admin: <strong><%= admin.getFullName() %></strong>
        </span>

        <a href="<%= request.getContextPath() %>/logout"
           class="btn btn-outline-light btn-sm">
            Logout
        </a>
    </div>
</nav>

<div class="container my-4">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-success">Coach Details Management</h2>

        <a href="<%= request.getContextPath() %>/admin-dashboard.jsp"
           class="btn btn-secondary">
            Back to Dashboard
        </a>
    </div>

    <% if ("failed".equals(request.getParameter("error"))) { %>
        <div class="alert alert-danger">
            Failed to add coach. Please try again.
        </div>
    <% } %>

    <!-- Add Coach Form -->
    <div class="card shadow-sm border-0 mb-4">
        <div class="card-header bg-success text-white">
            <h5 class="mb-0">Add Coach Details</h5>
        </div>

        <div class="card-body">
            <form action="<%= request.getContextPath() %>/addCoach"
                  method="post">

                <div class="row g-3">

                    <div class="col-md-6">
                        <label class="form-label">Coach Name</label>
                        <input type="text"
                               name="coachName"
                               class="form-control"
                               placeholder="Enter coach name"
                               required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Specialization</label>
                        <input type="text"
                               name="specialization"
                               class="form-control"
                               placeholder="Example: Batting Coach"
                               required>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Experience (Years)</label>
                        <input type="number"
                               name="experience"
                               class="form-control"
                               min="0"
                               placeholder="Enter experience"
                               required>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Phone Number</label>
                        <input type="text"
                               name="phone"
                               class="form-control"
                               placeholder="Enter phone number"
                               required>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Email</label>
                        <input type="email"
                               name="email"
                               class="form-control"
                               placeholder="Enter email"
                               required>
                    </div>

                    <div class="col-12">
                        <button type="submit"
                                class="btn btn-success px-4">
                            Add Coach
                        </button>
                    </div>

                </div>
            </form>
        </div>
    </div>

    <!-- Coach List -->
    <div class="card shadow-sm border-0">
        <div class="card-header bg-dark text-white">
            <h5 class="mb-0">Registered Coaches</h5>
        </div>

        <div class="card-body">

            <% if (coaches == null || coaches.isEmpty()) { %>

                <div class="alert alert-info mb-0">
                    No coach details available.
                </div>

            <% } else { %>

                <div class="table-responsive">
                    <table class="table table-bordered table-hover align-middle">
                        <thead class="table-success">
                            <tr>
                                <th>ID</th>
                                <th>Coach Name</th>
                                <th>Specialization</th>
                                <th>Experience</th>
                                <th>Phone</th>
                                <th>Email</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <% for (Coach coach : coaches) { %>
                                <tr>
                                    <td><%= coach.getCoachId() %></td>
                                    <td><%= coach.getCoachName() %></td>
                                    <td><%= coach.getSpecialization() %></td>
                                    <td><%= coach.getExperience() %> years</td>
                                    <td><%= coach.getPhone() %></td>
                                    <td><%= coach.getEmail() %></td>
                                    <td>
                                        <a href="<%= request.getContextPath() %>/deleteCoach?coachId=<%= coach.getCoachId() %>"
                                           class="btn btn-danger btn-sm"
                                           onclick="return confirm('Are you sure you want to delete this coach?');">
                                            Delete
                                        </a>
                                    </td>
                                </tr>
                            <% } %>
                        </tbody>
                    </table>
                </div>

            <% } %>

        </div>
    </div>

</div>

</body>
</html>