<%@ page import="com.academy.dao.UserDAO, com.academy.model.User" %>
<%
    User currentUser = (User) session.getAttribute("user");
    if (currentUser == null || !"ADMIN".equals(currentUser.getRole())) {
        response.sendRedirect("login.jsp");
        return;
    }

    String idParam = request.getParameter("id");
    if (idParam != null && !idParam.trim().isEmpty()) {
        try {
            int userId = Integer.parseInt(idParam);
            new UserDAO().deleteUser(userId);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    response.sendRedirect("admin-dashboard.jsp?success=User+deleted+successfully");
%>