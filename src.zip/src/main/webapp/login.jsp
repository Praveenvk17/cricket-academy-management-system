<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>Cricket Academy - Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex align-items-center" style="min-height: 100vh;">
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="card shadow-lg p-4 border-0 rounded-4">
                <h3 class="text-center text-primary fw-bold mb-3">Cricket Academy</h3>
                <h6 class="text-center text-muted mb-4">Login to Performance Portal</h6>
                
                <% if(request.getAttribute("error") != null) { %>
                    <div class="alert alert-danger py-2"><%= request.getAttribute("error") %></div>
                <% } %>
                <% if("true".equals(request.getParameter("registered"))) { %>
                    <div class="alert alert-success py-2">Registration successful! Please login.</div>
                <% } %>

                <form action="login" method="post">
                    <div class="mb-3">
                        <label class="form-label">Email Address</label>
                        <input type="email" name="email" class="form-control" placeholder="name@domain.com" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-control" placeholder="••••••••" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100 py-2 fw-semibold">Sign In</button>
                </form>
                <div class="text-center mt-3">
                    <a href="register.jsp" class="text-decoration-none">New Player? Register here</a>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>