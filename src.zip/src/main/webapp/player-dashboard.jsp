<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.academy.model.User, com.academy.dao.PerformanceDAO, com.academy.model.Performance, java.util.List" %>
<%
    User user = (User) session.getAttribute("user");
    if(user == null || !"PLAYER".equals(user.getRole())) {
        response.sendRedirect("login.jsp");
        return;
    }
    List<Performance> list = new PerformanceDAO().findByPlayer(user.getId());
%>
<!DOCTYPE html>
<html>
<head>
    <title>Player Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<nav class="navbar navbar-dark bg-dark px-4 shadow">
    <span class="navbar-brand fw-bold">🏏 Cricket Academy Portal</span>
    <div>
        <span class="text-white me-3">Player: <strong><%= user.getFullName() %></strong></span>
        <a href="logout" class="btn btn-outline-danger btn-sm">Logout</a>
    </div>
</nav>

<div class="container my-4">
    <div class="card p-4 shadow-sm border-0 mb-4">
        <h4>Player Profile</h4>
        <p class="mb-1"><strong>Specialization:</strong> <%= user.getSpecialization() %></p>
        <p class="mb-0"><strong>Email:</strong> <%= user.getEmail() %> | <strong>Phone:</strong> <%= user.getPhone() %></p>
    </div>

    <div class="card p-4 shadow-sm border-0">
        <h4 class="mb-3">Performance & Match Evaluations</h4>
        <table class="table table-bordered table-hover align-middle">
            <thead class="table-primary">
                <tr>
                    <th>Date</th>
                    <th>Coach</th>
                    <th>Runs (Balls)</th>
                    <th>Strike Rate</th>
                    <th>Wickets (Overs)</th>
                    <th>Fitness (1-10)</th>
                    <th>Coach Feedback</th>
                </tr>
            </thead>
            <tbody>
                <% if(list.isEmpty()) { %>
                    <tr><td colspan="7" class="text-center text-muted">No practice/match evaluations yet.</td></tr>
                <% } else { 
                    for(Performance p : list) { %>
                    <tr>
                        <td><%= p.getSessionDate() %></td>
                        <td><%= p.getCoachName() %></td>
                        <td><%= p.getRunsScored() %> (<%= p.getBallsFaced() %>)</td>
                        <td><span class="badge bg-success"><%= String.format("%.1f", p.getStrikeRate()) %></span></td>
                        <td><%= p.getWicketsTaken() %> / <%= p.getRunsConceded() %> (<%= p.getOversBowled() %> ov)</td>
                        <td><strong><%= p.getFitnessRating() %>/10</strong></td>
                        <td><%= p.getCoachFeedback() != null ? p.getCoachFeedback() : "-" %></td>
                    </tr>
                <% } } %>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>