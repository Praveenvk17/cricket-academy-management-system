<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>Cricket Academy - Player Registration</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light py-5">
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card shadow-lg p-4 border-0 rounded-4">
                <h3 class="text-center text-primary fw-bold mb-3">Player Registration</h3>
                <% if(request.getAttribute("error") != null) { %>
                    <div class="alert alert-danger py-2"><%= request.getAttribute("error") %></div>
                <% } %>
                <form action="register" method="post">
                    <div class="mb-3">
                        <label class="form-label">Full Name</label>
                        <input type="text" name="fullName" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email Address</label>
                        <input type="email" name="email" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Phone</label>
                        <input type="text" name="phone" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Specialization</label>
                        <select name="specialization" class="form-select" required>
                            <option value="BATTING">Batting</option>
                            <option value="FAST_BOWLING">Fast Bowling</option>
                            <option value="SPIN_BOWLING">Spin Bowling</option>
                            <option value="WICKET_KEEPING">Wicket Keeping</option>
                            <option value="ALL_ROUNDER">All Rounder</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100 py-2 fw-semibold">Register as Player</button>
                </form>
                <div class="text-center mt-3">
                    <a href="login.jsp" class="text-decoration-none">Already registered? Login</a>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>