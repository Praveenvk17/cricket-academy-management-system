<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<%@ page import="com.academy.model.User" %>
<%@ page import="com.academy.model.Performance" %>
<%@ page import="com.academy.dao.PerformanceDAO" %>
<%@ page import="java.util.List" %>
<%@ page import="java.sql.SQLException" %>

<%
    User user = (User) session.getAttribute("user");

    if (user == null ||
        (!"ADMIN".equalsIgnoreCase(user.getRole())
        && !"COACH".equalsIgnoreCase(user.getRole()))) {

        response.sendRedirect("login.jsp");
        return;
    }

    List<Performance> performances = null;
    String errorMessage = null;

    try {
        performances = new PerformanceDAO().getAllPerformances();
    } catch (SQLException e) {
        errorMessage = "Unable to load service reports.";
        e.printStackTrace();
    }
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Service Reports - Cricket Academy</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
        rel="stylesheet">
</head>

<body class="bg-light">

<nav class="navbar navbar-dark bg-success px-4 shadow">
    <span class="navbar-brand fw-bold">
        🏏 Cricket Academy - Service Reports
    </span>

    <div>
        <span class="text-white me-3">
            Welcome, <strong><%= user.getFullName() %></strong>
        </span>

        <a href="<%= request.getContextPath() %>/logout"
           class="btn btn-outline-light btn-sm">
            Logout
        </a>
    </div>
</nav>

<div class="container-fluid my-4">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-success">Player Performance Service Report</h2>

        <% if ("ADMIN".equalsIgnoreCase(user.getRole())) { %>
            <a href="<%= request.getContextPath() %>/admin-dashboard.jsp"
               class="btn btn-secondary">
                Back to Dashboard
            </a>
        <% } else { %>
            <a href="<%= request.getContextPath() %>/coach-dashboard.jsp"
               class="btn btn-secondary">
                Back to Dashboard
            </a>
        <% } %>
    </div>

    <% if (errorMessage != null) { %>
        <div class="alert alert-danger">
            <%= errorMessage %>
        </div>
    <% } %>

    <div class="card shadow-sm border-0">
        <div class="card-header bg-dark text-white">
            <h5 class="mb-0">Performance Report History</h5>
        </div>

        <div class="card-body">

            <% if (performances == null || performances.isEmpty()) { %>

                <div class="alert alert-info mb-0">
                    No performance records available.
                </div>

            <% } else { %>

                <div class="table-responsive">
                    <table class="table table-bordered table-hover align-middle">

                        <thead class="table-success">
                            <tr>
                                <th>S.No</th>
                                <th>Player Name</th>
                                <th>Coach Name</th>
                                <th>Session Date</th>
                                <th>Runs</th>
                                <th>Balls</th>
                                <th>Strike Rate</th>
                                <th>Wickets</th>
                                <th>Overs</th>
                                <th>Runs Conceded</th>
                                <th>Economy Rate</th>
                                <th>Fitness</th>
                                <th>Coach Feedback</th>
                            </tr>
                        </thead>

                        <tbody>
                            <%
                                int serialNumber = 1;

                                for (Performance p : performances) {
                            %>
                                <tr>
                                    <td><%= serialNumber++ %></td>
                                    <td><%= p.getPlayerName() %></td>
                                    <td><%= p.getCoachName() %></td>
                                    <td><%= p.getSessionDate() %></td>
                                    <td><%= p.getRunsScored() %></td>
                                    <td><%= p.getBallsFaced() %></td>
                                    <td>
                                        <%= String.format("%.2f", p.getStrikeRate()) %>
                                    </td>
                                    <td><%= p.getWicketsTaken() %></td>
                                    <td><%= p.getOversBowled() %></td>
                                    <td><%= p.getRunsConceded() %></td>
                                    <td>
                                        <%= String.format("%.2f", p.getEconomyRate()) %>
                                    </td>
                                    <td>
                                        <span class="badge bg-success">
                                            <%= p.getFitnessRating() %>/10
                                        </span>
                                    </td>
                                    <td><%= p.getCoachFeedback() %></td>
                                </tr>
                            <%
                                }
                            %>
                        </tbody>

                    </table>
                </div>

            <% } %>

        </div>
    </div>

</div>

</body>
</html>