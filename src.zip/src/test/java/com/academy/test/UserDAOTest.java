package com.academy.test;

import static org.junit.Assert.*;
import org.junit.BeforeClass;
import org.junit.Test;
import com.academy.dao.UserDAO;
import com.academy.model.User;
import java.util.List;

public class UserDAOTest {

    private static UserDAO userDAO;

    @BeforeClass
    public static void setUp() {
        userDAO = new UserDAO();
    }

    @Test
    public void testGetUsersWithFilterNotNull() {
        List<User> list = userDAO.getUsersWithFilter("", "ALL", 1, 5);
        assertNotNull("User list should not be null", list);
    }

    @Test
    public void testFilterByRolePlayer() {
        List<User> list = userDAO.getUsersWithFilter("", "PLAYER", 1, 5);
        for (User u : list) {
            assertEquals("PLAYER", u.getRole());
        }
    }

    @Test
    public void testTotalUserCountNonNegative() {
        int count = userDAO.getTotalUserCount("", "ALL");
        assertTrue("User count should be >= 0", count >= 0);
    }
}